package com.ibm.train.rest;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.ibm.train.entity.Train;
import com.ibm.train.exception.InvalidTrainException;
import com.ibm.train.service.TrainService;

@RestController
public class TrainController {

	@Autowired
	private TrainService service;
	
	@PostMapping(value = "/train", consumes = "application/json")
	public String addTrain(@RequestBody Train t) {
		int tcode = service.addTrain(t);
		return "Train added with code : " + tcode;
	}
	
	@GetMapping(value = "/train/{tcode}", produces = "application/json")
	public Train getTrain(@PathVariable("tcode") int tcode) {
		Train t = null;
		try {
			t = service.getTrain(tcode);
		} catch (InvalidTrainException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, String.format(e.getMessage()));
		}
		return t;
	}
	
	@GetMapping(value = "/trains", produces = "application/json")
	public Collection<Train> getAll(){
		return service.getAll();
	}
	
//	@GetMapping(value = "/deltrain/{tcode}", produces = "application/json")
//	public String delTrain(@PathVariable("tcode") int tcode) {
//		try {
//			service.removeTrain(tcode);
//		} catch (InvalidTrainException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(e.getMessage()));
//		}
//		return "Train deleted with code : " + tcode;
//	}
	
}
