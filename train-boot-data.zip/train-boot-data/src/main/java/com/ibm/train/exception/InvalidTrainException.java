package com.ibm.train.exception;

public class InvalidTrainException extends Exception {

	public InvalidTrainException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidTrainException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
